from setuptools import setup, find_packages

setup(
    name='AssembleAI',
    version='0.1.0',
    packages=['Assemble-AI']
)